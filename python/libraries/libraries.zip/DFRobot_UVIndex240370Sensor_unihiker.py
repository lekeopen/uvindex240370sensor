# -*- coding: utf-8 -*-
'''!
  @file       DFRobot_UVIndex240370Sensor_unihiker.py
  @brief      行空板(Unihiker)专用的UV指数传感器(240370)Python库
  @copyright  Copyright (c) 2021 DFRobot Co.Ltd (http://www.dfrobot.com)
  @license    The MIT License (MIT)
  @author     fary(feng.yang@dfrobot.com), 行空板修订版
  @version    V2.1
  @date       2025-5-11
'''

import time
import warnings

# 行空板上使用标准smbus库进行I2C通信
try:
    import smbus
    SMBUS_AVAILABLE = True
except ImportError:
    SMBUS_AVAILABLE = False
    print("警告: 未能导入smbus库，I2C功能将不可用")
    print("请执行 'pip install smbus' 安装必要的库")

# 传感器常量定义
UVINDEX240370SENSOR_DEVICE_ADDR = 0x23      # 行空板上的默认地址
UVINDEX240370SENSOR_DEVICE_ADDR_ALT = 0x38  # 标准地址
REG_PID = 0x00                              # PID寄存器地址
UVINDEX240370SENSOR_INPUTREG_UVS_DATA = 0x06
UVINDEX240370SENSOR_INPUTREG_UVS_INDEX = 0x07
UVINDEX240370SENSOR_INPUTREG_RISK_LEVEL = 0x08
UVINDEX240370SENSOR_DEVICE_PID = 0x427c

class DFRobot_UVIndex240370Sensor():
    I2C_MODE = 0x01
    UART_MODE = 0x02
    
    # 缓存上次读取的值，用于出错时返回
    _last_data = 0
    _last_index = 0
    _last_risk = 0
    
    def __init__(self, bus=None, mode=I2C_MODE, addr=None):
        """初始化传感器通信
        
        参数:
            bus: I2C总线号，如果为None，则自动尝试总线0和1
            mode: 通信模式，目前仅支持I2C_MODE
            addr: 传感器地址，如果为None，则自动尝试0x23和0x38
        """
        self._uart_i2c = mode
        self.i2cbus = None
        self.debug_mode = False
        
        # 设置传感器地址
        self._addr = addr if addr is not None else UVINDEX240370SENSOR_DEVICE_ADDR
        self._alt_addr = UVINDEX240370SENSOR_DEVICE_ADDR_ALT
        self._current_addr = self._addr  # 当前使用的地址
        
        # 检查库是否可用
        if mode != self.I2C_MODE:
            warnings.warn("目前仅支持I2C模式", RuntimeWarning)
            return
            
        if not SMBUS_AVAILABLE:
            print("错误: 缺少smbus库，无法进行I2C通信")
            return
            
        # 如果总线未指定，将在begin()中自动扫描
        self._bus = bus
        if bus is not None:
            try:
                self.i2cbus = smbus.SMBus(bus)
                print(f"I2C初始化成功，总线:{bus}")
            except Exception as e:
                print(f"I2C初始化失败: {str(e)}")
                self.i2cbus = None

    def set_debug(self, debug):
        """设置调试模式
        
        参数:
            debug: 是否开启调试模式
        """
        self.debug_mode = debug
        
    def begin(self):
        """初始化传感器，自动扫描可用的I2C总线和地址
        
        返回:
            成功返回True，失败返回False
        """
        if self._uart_i2c != self.I2C_MODE:
            print("错误: 仅支持I2C模式")
            return False
            
        if not SMBUS_AVAILABLE:
            print("错误: 缺少smbus库，无法进行I2C通信")
            return False
            
        # 如果总线明确指定且已初始化，则直接使用
        if self._bus is not None and self.i2cbus is not None:
            return self._check_sensor_addresses()
            
        # 否则，扫描可能的总线
        print("自动扫描I2C总线和传感器地址...")
        for bus_num in [0, 1]:
            try:
                if self.debug_mode:
                    print(f"尝试总线 {bus_num}...")
                self.i2cbus = smbus.SMBus(bus_num)
                self._bus = bus_num
                
                # 检查传感器地址
                if self._check_sensor_addresses():
                    return True
                    
                # 如果当前总线未找到设备，关闭总线准备尝试下一个
                self.i2cbus.close()
                    
            except Exception as e:
                if self.debug_mode:
                    print(f"总线 {bus_num} 初始化失败: {e}")
                if self.i2cbus:
                    try:
                        self.i2cbus.close()
                    except:
                        pass
        
        # 如果所有尝试都失败
        print("错误: 未找到紫外线传感器，请检查连接")
        self.i2cbus = None
        return False
        
    def _check_sensor_addresses(self):
        """检查配置的传感器地址是否有效
        
        返回:
            成功找到传感器返回True，否则返回False
        """
        # 先尝试主地址
        try:
            pid = self._read_pid(self._addr)
            if pid == UVINDEX240370SENSOR_DEVICE_PID:
                print(f"成功检测到紫外线传感器，地址0x{self._addr:02X}，PID=0x{pid:04X}")
                self._current_addr = self._addr
                return True
            elif self.debug_mode:
                print(f"地址0x{self._addr:02X}设备ID不匹配: 0x{pid:04X}")
        except Exception as e:
            if self.debug_mode:
                print(f"地址0x{self._addr:02X}读取失败: {e}")
        
        # 再尝试备用地址
        try:
            pid = self._read_pid(self._alt_addr)
            if pid == UVINDEX240370SENSOR_DEVICE_PID:
                print(f"成功检测到紫外线传感器，地址0x{self._alt_addr:02X}，PID=0x{pid:04X}")
                self._current_addr = self._alt_addr
                return True
            elif self.debug_mode:
                print(f"地址0x{self._alt_addr:02X}设备ID不匹配: 0x{pid:04X}")
        except Exception as e:
            if self.debug_mode:
                print(f"地址0x{self._alt_addr:02X}读取失败: {e}")
                
        return False
        
    def _read_pid(self, addr):
        """从设备读取PID
        
        参数:
            addr: 设备地址
            
        返回:
            设备PID值
        """
        try:
            msb = self.i2cbus.read_byte_data(addr, REG_PID)
            lsb = self.i2cbus.read_byte_data(addr, REG_PID+1)
            return (msb << 8) | lsb
        except Exception as e:
            if self.debug_mode:
                print(f"从地址0x{addr:02X}读取PID失败: {e}")
            return 0
  
    def read_UV_original_data(self):
        """读取紫外线原始数据
        
        返回:
            紫外线原始数据值(mV)，错误返回0
        """
        if self.i2cbus is None:
            print("错误: I2C总线未初始化，请先调用begin()")
            return self._last_data
            
        try:
            result = self._read_register(self._current_addr, UVINDEX240370SENSOR_INPUTREG_UVS_DATA)
                
            # 确保结果在合理范围内
            if result > 10000:  # 非常高的值可能是错误读数
                print(f"警告: 读取到异常高的数值 ({result} mV)，可能是通信错误")
                return self._last_data
                
            self._last_data = result
            if self.debug_mode:
                print(f"紫外线原始值: {result} mV")
            return result
        except Exception as e:
            print(f"读取紫外线数据错误: {str(e)}")
            return self._last_data

    def read_UV_index_data(self):
        """读取紫外线指数
        
        返回:
            紫外线指数值，错误返回0
        """
        if self.i2cbus is None:
            print("错误: I2C总线未初始化，请先调用begin()")
            return self._last_index
            
        try:
            # 每次读取前强制等待一小段时间，防止数据重叠
            time.sleep(0.05)
            
            result = self._read_register(self._current_addr, UVINDEX240370SENSOR_INPUTREG_UVS_INDEX)
                
            # 检查结果是否合理 (UV指数通常为0-11)
            if result > 15:
                print(f"警告: UV指数异常 ({result})，可能是通信错误")
                return self._last_index
                
            self._last_index = result
            if self.debug_mode:
                uv_risk = "低风险" if result <= 2 else "中风险" if result <= 5 else "高风险" if result <= 7 else "很高风险" if result <= 10 else "极高风险"
                print(f"紫外线指数: {result} ({uv_risk})")
            return result
        except Exception as e:
            print(f"读取紫外线指数错误: {str(e)}")
            return self._last_index

    def read_risk_level_data(self):
        """读取风险等级
        
        返回:
            风险等级值，错误返回0
        """
        if self.i2cbus is None:
            print("错误: I2C总线未初始化，请先调用begin()")
            return self._last_risk
            
        try:
            # 每次读取前强制等待一小段时间，防止数据重叠
            time.sleep(0.05)
            
            result = self._read_register(self._current_addr, UVINDEX240370SENSOR_INPUTREG_RISK_LEVEL)
            
            # 风险等级应该在0-4之间
            if result > 4:
                print(f"警告: 风险等级异常 ({result})，可能是通信错误")
                return self._last_risk
                
            self._last_risk = result
            if self.debug_mode:
                risk_names = ["低风险", "中风险", "高风险", "很高风险", "极高风险"]
                risk_name = risk_names[result] if 0 <= result < len(risk_names) else "未知"
                print(f"紫外线风险等级: {result} ({risk_name})")
            return result
        except Exception as e:
            print(f"读取风险等级错误: {str(e)}")
            return self._last_risk

    def _read_register(self, addr, reg):
        """读取传感器寄存器
        
        参数:
            addr: 设备地址
            reg: 寄存器地址
            
        返回:
            16位寄存器值
        """
        try:
            # 方法1: 直接读取字
            return self.i2cbus.read_word_data(addr, reg)
        except Exception as e1:
            if self.debug_mode:
                print(f"方法1读取失败: {e1}，尝试方法2...")
                
            try:
                # 方法2: 分别读取字节并组合
                msb = self.i2cbus.read_byte_data(addr, reg)
                lsb = self.i2cbus.read_byte_data(addr, reg+1)
                return (msb << 8) | lsb
            except Exception as e2:
                if self.debug_mode:
                    print(f"方法2读取失败: {e2}，尝试方法3...")
                    
                try:
                    # 方法3: 写入地址后直接读取
                    self.i2cbus.write_byte(addr, reg)
                    time.sleep(0.01)
                    msb = self.i2cbus.read_byte(addr)
                    time.sleep(0.01)
                    lsb = self.i2cbus.read_byte(addr)
                    return (msb << 8) | lsb
                except Exception as e3:
                    raise Exception(f"所有读取方法均失败: {e3}")

class DFRobot_UVIndex240370Sensor_I2C(DFRobot_UVIndex240370Sensor):
    def __init__(self, bus=None, addr=None):
        """初始化I2C模式传感器
        
        参数:
            bus: I2C总线号，如果为None，则自动尝试总线0和1
            addr: 设备地址，如果为None，则自动尝试0x23和0x38
        """
        DFRobot_UVIndex240370Sensor.__init__(self, bus, self.I2C_MODE, addr)
