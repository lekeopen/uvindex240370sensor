#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''!
  @file       unihiker_uv_patch_v2.py
  @brief      行空板(Unihiker)紫外线指数传感器(240370)补丁文件 - 增强版
  @copyright  Copyright (c) 2021-2025 DFRobot Co.Ltd (http://www.dfrobot.com)
  @license    The MIT License (MIT)
  @version    V2.0.1
  @date       2025-5-12
  
  使用说明:
  1. 将此文件复制到Mind+扩展的python/libraries目录中
  2. 在代码中使用 from unihiker_uv_patch_v2 import PatchUVSensor
  3. 创建传感器对象: sensor = PatchUVSensor()
  4. 使用方法:
     - sensor.begin() - 初始化传感器
     - sensor.read_UV_original_data() - 读取原始值
     - sensor.read_UV_index_data() - 读取UV指数
     - sensor.read_risk_level_data() - 读取风险等级
'''

import time
import warnings
import sys
import os
import random
import smbus

# 传感器常量定义
UVINDEX240370SENSOR_DEVICE_ADDR = 0x23      # 行空板上的默认地址
UVINDEX240370SENSOR_DEVICE_ADDR_ALT = 0x38  # 标准地址
REG_PID = 0x00                              # PID寄存器地址
UVINDEX240370SENSOR_INPUTREG_UVS_DATA = 0x06
UVINDEX240370SENSOR_INPUTREG_UVS_INDEX = 0x07
UVINDEX240370SENSOR_INPUTREG_RISK_LEVEL = 0x08
# 原始设备ID和字节序颠倒的设备ID
UVINDEX240370SENSOR_DEVICE_PID = 0x427c
UVINDEX240370SENSOR_DEVICE_PID_REVERSED = 0x7c42  # 字节序颠倒的设备ID

class PatchUVSensor:
    """增强版行空板紫外线传感器类"""
    def __init__(self, simulation_mode=False, debug_mode=False):
        """初始化传感器对象
        
        Args:
            simulation_mode (bool): 是否使用模拟模式（无硬件情况下测试）
            debug_mode (bool): 是否启用调试输出
        """
        self._simulation_mode = simulation_mode
        self._debug_mode = debug_mode
        self._bus = None
        self._bus_num = None
        self._address = None
        self._device_id = None
        self._is_connected = False
        self._last_raw_value = random.randint(100, 300)  # 用于模拟模式
        self._interface_type = "SMBUS"
        
        # 模拟模式初始信息
        if self._simulation_mode:
            self._debug_print("[UV传感器] 启动模拟模式，不使用实际硬件")
    
    def _debug_print(self, msg):
        """调试信息输出"""
        if self._debug_mode:
            print(msg)
    
    def begin(self):
        """初始化传感器，自动扫描可用总线和地址
        
        Returns:
            bool: 是否成功初始化
        """
        # 模拟模式直接返回成功
        if self._simulation_mode:
            self._is_connected = True
            self._debug_print("[UV传感器] 模拟模式已激活")
            return True
        
        # 使用SMBUS接口
        self._debug_print("[UV传感器] 使用SMBUS接口初始化传感器")
        return self._scan_i2c_buses()
    
    def _scan_i2c_buses(self):
        """扫描所有可能的I2C总线和地址
        
        Returns:
            bool: 是否找到传感器
        """
        self._debug_print("[UV传感器] 开始扫描I2C总线...")
        
        # 常用的总线列表
        bus_list = [1, 0, 2, 3, 4, 5, 6, 7]  # 优先尝试常用总线
        
        # 地址列表
        addr_list = [UVINDEX240370SENSOR_DEVICE_ADDR, UVINDEX240370SENSOR_DEVICE_ADDR_ALT]
        
        # 尝试所有总线
        for bus_num in bus_list:
            self._debug_print(f"[UV传感器] 尝试总线 {bus_num}...")
            try:
                bus = smbus.SMBus(bus_num)
                
                # 尝试常用地址
                for addr in addr_list:
                    try:
                        # 尝试读取设备ID
                        data = bus.read_i2c_block_data(addr, REG_PID, 2)
                        device_id = (data[0] << 8) | data[1]
                        self._debug_print(f"[UV传感器] 总线{bus_num}地址0x{addr:02X}的设备ID: 0x{device_id:04X}")
                        
                        # 尝试字节序变换，看看是否匹配
                        device_id_reversed = ((device_id & 0xFF) << 8) | ((device_id >> 8) & 0xFF)
                        self._debug_print(f"[UV传感器] 尝试字节序变换: 原始ID=0x{device_id:04X}, 变换后=0x{device_id_reversed:04X}")
                        
                        # 验证设备ID
                        if device_id == UVINDEX240370SENSOR_DEVICE_PID or device_id == UVINDEX240370SENSOR_DEVICE_PID_REVERSED:
                            # 找到了！
                            self._debug_print(f"[UV传感器] ✓ 总线{bus_num}上找到紫外线传感器(地址0x{addr:02X})")
                            self._bus = bus
                            self._bus_num = bus_num
                            self._address = addr
                            self._device_id = device_id
                            self._is_connected = True
                            print(f"自动扫描I2C总线和传感器地址成功")
                            print(f"总线: {bus_num}, 地址: 0x{addr:02X}")
                            return True
                    except Exception as e:
                        self._debug_print(f"[UV传感器] 总线{bus_num}地址0x{addr:02X}通信失败: {e}")
                
                # 如果循环结束还没有找到设备，关闭总线继续尝试
                bus.close()
            except Exception as e:
                self._debug_print(f"[UV传感器] 扫描总线{bus_num}地址0x{addr:02X}时出错: {e}")
        
        # 如果扫描完所有总线和地址仍未找到，返回失败
        self._is_connected = False
        print("错误: 未找到紫外线传感器，请检查连接")
        print("✗ 未能找到紫外线传感器")
        print("  - 请确认传感器已正确连接")
        print("  - 检查I2C连接线是否牢固")
        print("  - 确认传感器电源正常") 
        print("  - 可能需要重启行空板")
        return False
    
    def _check_connection(self):
        """检查传感器连接状态
        
        Returns:
            bool: 是否已连接
        """
        if self._simulation_mode:
            return True
        return self._is_connected
    
    def read_UV_original_data(self):
        """读取紫外线原始数据
        
        Returns:
            int: 紫外线原始数据
        """
        # 模拟模式返回模拟数据
        if self._simulation_mode:
            # 生成真实的随机波动数据
            self._last_raw_value = max(100, min(20000, self._last_raw_value + random.randint(-500, 500)))
            return self._last_raw_value
        
        # 检查连接状态
        if not self._check_connection():
            print("错误: 未连接传感器，无法读取原始数据")
            return 0
        
        # 读取数据
        try:
            data = self._bus.read_i2c_block_data(self._address, UVINDEX240370SENSOR_INPUTREG_UVS_DATA, 2)
            raw_value = (data[0] << 8) | data[1]
            
            # 数据有效性检查与修复
            if raw_value > 30000:  # 异常大的值可能是字节序问题
                raw_value = ((raw_value & 0xFF) << 8) | ((raw_value >> 8) & 0xFF)
            
            return raw_value
        except Exception as e:
            print(f"错误: 读取UV原始数据失败: {e}")
            return 0
    
    def read_UV_index_data(self):
        """读取UV指数数据
        
        Returns:
            int: UV指数
        """
        # 模拟模式
        if self._simulation_mode:
            raw = self.read_UV_original_data()
            return min(11, max(0, int(raw / 1800)))
        
        # 检查连接状态
        if not self._check_connection():
            print("错误: 未连接传感器，无法读取UV指数")
            return 0
        
        # 读取数据
        try:
            data = self._bus.read_i2c_block_data(self._address, UVINDEX240370SENSOR_INPUTREG_UVS_INDEX, 2)
            uv_index = (data[0] << 8) | data[1]
            
            # 数据有效性检查
            if uv_index > 20:  # UV指数通常不会超过20
                uv_index = min(11, max(0, uv_index % 12))
            
            return uv_index
        except Exception as e:
            print(f"错误: 读取UV指数失败: {e}")
            return 0
    
    def read_risk_level_data(self):
        """读取风险等级数据
        
        Returns:
            int: 风险等级，0-4
        """
        # 模拟模式
        if self._simulation_mode:
            uv_index = self.read_UV_index_data()
            # 根据UV指数确定风险等级
            if uv_index <= 2:
                return 0  # 低风险
            elif uv_index <= 5:
                return 1  # 中等风险
            elif uv_index <= 7:
                return 2  # 高风险
            elif uv_index <= 10:
                return 3  # 很高风险
            else:
                return 4  # 极高风险
        
        # 检查连接状态
        if not self._check_connection():
            print("错误: 未连接传感器，无法读取风险等级")
            return 0
        
        # 读取数据
        try:
            data = self._bus.read_i2c_block_data(self._address, UVINDEX240370SENSOR_INPUTREG_RISK_LEVEL, 2)
            risk_level = (data[0] << 8) | data[1]
            
            # 检查风险等级范围
            if risk_level > 4:  # 风险等级是0-4
                risk_level = min(4, max(0, risk_level % 5))
            
            return risk_level
        except Exception as e:
            print(f"错误: 读取风险等级失败: {e}")
            return 0
